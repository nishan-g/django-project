from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    context={
         'variable':"hello world",
         'variable1':"dunia maderchod hai, maderchod thi or maderchod rahegi ",
         'variable2':"babylone jindabad"
            }
    return render(request,'index.html',context)
    # return HttpResponse("this is homepage")

def about(request):
    return render(request,'about.html')
    # return HttpResponse("this is about page")   
    
def services(request):
    return render(request,'services.html')
    # return HttpResponse("this is services")    


def contact(request):
    return render(request,'contact.html')
    #return HttpResponse("this is our contact")    
def Home(request):
   # return render(request,'Home.html')
   return HttpResponse("this is our Homepage")    
